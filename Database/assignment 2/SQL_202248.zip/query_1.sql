SELECT B.name
FROM "Beers" B
WHERE B.manf = 'Anheuser-Busch';
