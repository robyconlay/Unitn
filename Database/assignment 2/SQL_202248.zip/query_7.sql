SELECT DISTINCT
ROUND(price::numeric, 2)
FROM "Sells";
